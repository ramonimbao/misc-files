#include QMK_KEYBOARD_H
#include "app_ble_func.h"

#include <quantum.h>

const uint8_t is_master = IS_LEFT_HAND;

// Each layer gets a name for readability, which is then used in the keymap matrix below.
// The underscores don't mean anything - you can have a layer called STUFF or any other name.
// Layer names don't all need to be of the same length, obviously, and you can also skip them
// entirely and just use numbers.
#define _BASE 0
#define _FN 1

#define _____ KC_TRNS

enum custom_keycodes {
  ENT_SLP = SAFE_RANGE,
  BATT_LV,
  ADV_ID0,
  ADV_ID1,
  ADV_ID2,
  ADV_ID3,
  ADV_ID4,
  DEL_ID0,
  DEL_ID1,
  DEL_ID2,
  DEL_ID3,
  DEL_ID4,
};

// Tap dance declarations
enum {
  TD_ID0,
  TD_ID1,
  TD_ID2,
  TD_ID3,
  TD_ID4
};

qk_tap_dance_action_t tap_dance_actions[] = {
  [TD_ID0] = ACTION_TAP_DANCE_DOUBLE(ADV_ID0, DEL_ID0),
  [TD_ID1] = ACTION_TAP_DANCE_DOUBLE(ADV_ID1, DEL_ID1),
  [TD_ID2] = ACTION_TAP_DANCE_DOUBLE(ADV_ID2, DEL_ID2),
  [TD_ID3] = ACTION_TAP_DANCE_DOUBLE(ADV_ID3, DEL_ID3),
  [TD_ID4] = ACTION_TAP_DANCE_DOUBLE(ADV_ID4, DEL_ID4)
};

#define TD0 TD(TD_ID0)
#define TD1 TD(TD_ID1)
#define TD2 TD(TD_ID2)
#define TD3 TD(TD_ID3)
#define TD4 TD(TD_ID4)

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [_BASE] = LAYOUT(
    KC_ESC, KC_GESC, KC_1, KC_2, KC_3, KC_4, KC_5, KC_6, KC_7, KC_8, KC_9, KC_0, KC_MINS, KC_EQL, KC_GRAVE, KC_BSLASH,
    KC_PGUP, KC_TAB, KC_Q, KC_W, KC_E, KC_R, KC_T, KC_Y, KC_U, KC_I, KC_O, KC_P, KC_LBRC, KC_RBRC, KC_BSPACE,
    KC_PGDN, KC_LCTL, KC_A, KC_S, KC_D, KC_F, KC_G, KC_H, KC_J, KC_K, KC_L, KC_SCOLON, KC_QUOT, KC_ENTER,
             KC_LSFT, KC_Z, KC_X, KC_C, KC_V, KC_B, KC_N, KC_M, KC_COMMA, KC_DOT, KC_SLASH, KC_RSFT,
             KC_LGUI, KC_LALT, KC_SPACE, MO(_FN), KC_SPACE, KC_RALT, KC_RCTL
    ),

    [_FN] = LAYOUT(
      _____, _____, KC_F1, KC_F2, KC_F3, KC_F4, KC_F5, KC_F6, KC_F7, KC_F8, KC_F9, KC_F10, KC_F11, KC_F12, KC_INS, KC_DELETE,
      _____, KC_CAPS, TD0, TD1, TD2, TD3, TD4, _____, _____, KC_PSCR, KC_SLCK, KC_PAUS, KC_UP, _____, KC_DELETE,
      _____, _____, KC_VOLD, KC_VOLU, KC_MUTE, KC_EJCT, _____, KC_KP_ASTERISK, KC_KP_SLASH, KC_HOME, KC_PGUP, KC_LEFT, KC_RIGHT, _____,
             _____, _____, _____, _____, _____, _____, KC_KP_PLUS, KC_KP_MINUS, KC_END, KC_PGDN, KC_DOWN, _____,
             _____, _____, _____, _____, _____, KC_MEDIA_STOP, _____
    )
};

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  char str[16];

  if (record->event.pressed) {
    switch (keycode) {
      case BATT_LV:
        sprintf(str, "%4dmV", get_vcc());
        send_string(str);
        return false;
      case ADV_ID0:
        restart_advertising_id(0);
        return false;
      case ADV_ID1:
        restart_advertising_id(1);
        return false;
      case ADV_ID2:
        restart_advertising_id(2);
        return false;
      case ADV_ID3:
        restart_advertising_id(3);
        return false;
      case ADV_ID4:
        restart_advertising_id(4);
        return false;
      case DEL_ID0:
        delete_bond_id(0);
        return false;
      case DEL_ID1:
        delete_bond_id(1);
        return false;
      case DEL_ID2:
        delete_bond_id(2);
        return false;
      case DEL_ID3:
        delete_bond_id(3);
        return false;
      case DEL_ID4:
        delete_bond_id(4);
        return false;
    }
  } else if (!record->event.pressed) {
    switch (keycode) {
      case ENT_SLP:
        sleep_mode_enter();
        return false;
    }
  }

  return true;
}
