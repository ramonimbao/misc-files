#ifndef SLAVE_CONFIG_H_
#define SLAVE_CONFIG_H_

#include "custom_board.h"

#define IS_LEFT_HAND  false

#ifdef OLED_ENABLE
  #define SSD1306OLED
#endif

#endif /* SLAVE_CONFIG_H_ */
